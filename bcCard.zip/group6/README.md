
## UI template  

아래 주소에서 다운 받으셔서 활용 부탁드립니다. 라이선스 정책상  kt ds 직원만 내부 학습용으로 활용이 가능합니다. 외부직원에게 공유하거나 학습용도 외의 목적으로 불가능합니다. 강사님께도 공유해서는 안됩니다. 사용에 주의를 부탁드립니다. 

>https://devpro.ktds.co.kr:9999/2021/ui-template.git

<br>


## ㅇ 개발소스: gitlab

> https://devpro.ktds.co.kr:9999/
 
## ㅇ 빌드/배포: jenkins 
실습때 개별로 만든 maven, gradle job 확인가능

> http://14.63.223.122:9100/jenkins


<br>

## ㅇ 데이터베이스 : _mysql  (21-02-07 19:04 정상접속확인)
```
ssh root@14.63.214.22 -p 22 (접속가능, password: test8080!) 

```
## ㅇ 개발한 웹 어플리케이션을 배포할 서버 (21-02-07 19:05 정상접속확인)
```
ssh root@14.63.221.225 -p 22 (pw : test8080!)
```
### 조별 사용할 톰캣 (1조당 1개의 톰캣 사용) 
```
(경로 : 포트번호)
1조 : cd /usr/local/tomcat/group1/apache-tomcat-8.5.57/bin  8081
2조 : cd /usr/local/tomcat/group2/apache-tomcat-8.5.57/bin  8082
3조 : cd /usr/local/tomcat/group3/apache-tomcat-8.5.57/bin  8083
4조 : cd /usr/local/tomcat/group4/apache-tomcat-8.5.57/bin  8084
5조 : cd /usr/local/tomcat/group5/apache-tomcat-8.5.57/bin  8085
6조 : cd /usr/local/tomcat/group6/apache-tomcat-8.5.57/bin  8086
7조 : cd /usr/local/tomcat/group7/apache-tomcat-8.5.57/bin  8087
```

### 시작/ 정지는 위의 경로에서 아래 명령어 실시
```
./catalina.sh start (시작)
./catalina.sh stop (정지)
```
### 톰캣 기동 확인 

웹브라우저에서 아래 주소로 접속 (포트번호는 각 조별 부여된 번호 입력)
```
http://14.63.221.225:8081 
http://14.63.221.225:8082 
http://14.63.221.225:8083 
http://14.63.221.225:8084 
http://14.63.221.225:8085 
http://14.63.221.225:8086 
http://14.63.221.225:8087
```
### 배포 경로 
아래 경로에 *.war파일을 배포한다.
```
/설치경로/apache-tomcat-8.5.57/webapps
```
### 배포 확인
웹브라우저에서 아래 주소로 접속 (예시, 1조는 포트 8081을 사용하고, context test로 설정)
```
http://14.63.221.225:8081/test 
```
