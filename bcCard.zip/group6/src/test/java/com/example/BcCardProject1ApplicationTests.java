package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcCardProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
