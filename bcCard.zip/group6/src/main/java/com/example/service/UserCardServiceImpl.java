package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.dao.UserCardDao;
import com.example.dto.UserCardVO;

@Repository
public class UserCardServiceImpl implements UserCardService {

	@Autowired
	UserCardDao dao;

	@Override
	public List<UserCardVO> usercardList(String user_id) {
		return dao.usercardList(user_id);
	}

	@Override
	public UserCardVO selectByCardid(UserCardVO vo) {
		return dao.selectByCardid(vo);
	}

	@Override
	public UserCardVO selectByCardname(UserCardVO vo) {
		return dao.selectByCardname(vo);
	}

	@Override
	public int insertUsercard(UserCardVO vo) {
		// TODO Auto-generated method stub
		return dao.insertUsercard(vo);
	}

}
