package com.app2;

public abstract class shape {
	
	private int width;
	private int height;
	private String colors;
	
	public abstract double getArea();
	
	public shape() {
		// TODO Auto-generated constructor stub
	}
	public shape(int width, int height, String colors) {
		this.width = width;
		this.height = height;
		this.colors = colors;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public String getColors() {
		return colors;
	}
	public void setColors(String colors) {
		this.colors = colors;
	}
	
}
