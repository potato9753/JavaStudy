package com.app2;

import com.app3.Student;

public class ShapeTest {

	public static void main(String[] args) {
		
		shape shape []= {new Triangle(7,5,"Blue"),
				("Rectangle",4,6,"Blue"),new Triangle(,6,7,"Red"),
				("Rectangle",8,3,"Red"),new Triangle(,9,8,"White"),
				("Rectangle",5,7,"White")};
		
		Student studentArray [] = {new Student("홍길동", 15, 170, 80),new Student("한사람", 13, 180, 70),new Student("임걱정", 16, 175, 65)};
		
	}

}
