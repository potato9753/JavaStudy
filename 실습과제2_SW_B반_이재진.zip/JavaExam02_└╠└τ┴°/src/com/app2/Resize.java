package com.app2;

public interface Resize {
	public abstract void setResize(int size);
	
}
